# Changelog

## [1.0.0] 2018-07-25

### Original Release

## [1.0.1] 2018-08-21

- FIX: syntax error in _icons.scss
- FIX: double body/html tags in css

- UPDATE: sticky navbar with headroom.js (learn more in the docs, plugins/headroom)
- UPDATE: hero section for the index page
- UPDATE: added 2 new pages in the Docs (download and headroom)

- NEW: add npm, yarn, bower and composer for quick installation

## [1.1.0] 2019-06-20

- FIX: Responsive issues
- FIX: Fixed import paths

- UPDATE: Bootstrap 4.3.1
- UPDATE: Plugins updated
